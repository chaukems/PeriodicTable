/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package periodictable;

/**
 *
 * @author F4829689
 */
public enum Symbol {

    Li("Lithium", 3, "Li"),
    He("Helium", 2, "He"),
    Be("Beryllium", 4, "Be"),
    Ne("Neon", 10, "Ne"),
    Na("Sodium", 11, "Na"),
    Mg("Magnesium", 12, "Mg"),
    Al("Aluminium", 13, "Al"),
    Si("Silicon", 14, "Si"),
    Cl("Chlor­ine", 17, "Cl"),
    Ar("Argon", 18, "Ar"),
    Ca("Calcium", 20, "Ca"),
    Sc("Scandium", 21, "Sc"),
    Ti("Titanium", 22, "Ti"),
    Cr("Chromium", 24, "Cr"),
    Mn("Manganese", 25, "Mn"),
    Fe("Iron", 26, "Fe"),
    Co("Cobalt", 27, "Co"),
    Ni("Nickel", 28, "Ni"),
    Cu("Copper", 29, "Cu"),
    Zn("Zinc", 30, "Zn"),
    Ga("Gallium", 31, "Ga"),
    Ge("Germanium", 32, "Ge"),
    As("Arsenic", 33, "As"),
    Se("Selenium", 34, "Se"),
    Br("Bromine", 35, "Br"),
    Kr("Krypton", 36, "Kr"),
    Rb("Rubidium", 37, "Rb"),
    Sr("Strontium", 38, "Sr"),
    Zr("Zirconium", 40, "Zr"),
    Nb("Niobium", 41, "Nb"),
    Mo("Molybdenum", 42, "Mo"),
    Tc("Technetium", 43, "Tc"),
    Ru("Ruthenium", 44, "Ru"),
    Rh("Rhodium", 45, "Rh"),
    Pd("Palladium", 46, "Pd"),
    Ag("Silver", 47, "Ag"),
    Cd("Cadmium", 48, "Cd"),
    In("Indium", 49, "In"),
    Sn("Tin", 50, "Sn"),
    Sb("Antimony", 51, "Sb"),
    Te("Tellurium", 52, "Te"),
    Xe("Xenon", 54, "Xe"),
    Cs("Caesium", 55, "Cs"),
    Bu("Barium", 56, "Ba"),
    La("Lanthanum", 57, "La"),
    Hf("Hafnium", 72, "Hf"),
    Ta("Tantalum", 73, "Ta"),
    Re("Rhenium", 75, "Re"),
    Os("Osmium", 76, "Os"),
    Ir("Iridium", 77, "Ir"),
    Pt("Platinum", 78, "Pt"),
    Au("Gold", 79, "Au"),
    Hg("Mercury", 80, "Hg"),
    Tl("Thallium", 81, "Tl"),
    Pb("Lead", 82, "Pb"),
    Bi("Bismuth", 83, "Bi"),
    Po("Polo­nium", 84, "Po"),
    At("Astatine", 85, "At"),
    Rn("Radon", 86, "Rn"),
    Fr("Francium", 87, "Fr"),
    Ra("Radium", 88, "Ra"),
    Ac("Actinium", 89, "Ac"),
    Rf("Rutherfordium", 104, "Rf"),
    Db("Dubnium", 105, "Db"),
    Sg("Seaborgium", 106, "Sg"),
    Bh("Bohrium", 107, "Bh"),
    Hs("Hassium", 108, "Hs"),
    Mt("Meitnerium", 109, "Mt"),
    Ds("Darmstadtium", 110, "Ds"),
    Rg("Roentgenium", 111, "Rg"),
    Cn("Copernicium", 112, "Cn"),
    Nh("Nihonium", 113, "Nh"),
    Fl("Flerovium", 114, "Fl"),
    Mc("Moscovium", 115, "Mc"),
    Lv("Livermorium", 116, "Lv"),
    Ts("Tennessine", 117, "Ts"),
    Og("Oganesson", 118, "Og"),
    Ce("Cerium", 58, "Ce"),
    Pr("Praseodymium", 59, "Pr"),
    Nd("Neodymium", 60, "Nd"),
    Pm("Promethium", 61, "Pm"),
    Sm("Samarium", 62, "Sm"),
    Eu("Europium", 63, "Eu"),
    Gd("Gadolinium", 64, "Gd"),
    Tb("Terbium", 65, "Tb"),
    Dy("Dysprosium", 66, "Dy"),
    Ho("Holmium", 67, "Ho"),
    Er("Erbium", 68, "Er"),
    Tm("Thulium", 69, "Tm"),
    Yb("Ytterbium", 70, "Yb"),
    Lu("Lutetium", 71, "Lu"),
    Th("Thorium", 90, "Th"),
    Pa("Protactinium", 91, "Pa"),
    Np("Neptunium", 93, "Np"),
    Pu("Plutonium", 94, "Pu"),
    Am("Americium", 95, "Am"),
    Cm("Curium", 96, "Cm"),
    Bk("Berkelium", 97, "Bk"),
    Cf("Californium", 98, "Cf"),
    Es("Einsteinium", 99, "Es"),
    Fm("Fermium", 100, "Fm"),
    Md("Mendelevium", 101, "Md"),
    No("Nobelium", 102, "No"),
    Lr("Lawrencium", 103, "Lr");

    private final String name;       // name of element
    private final int number;     // number in periodic table
    private final String symbol;     // atomic symbol

    Symbol(String name, int number, String symbol) {
        this.name = name;
        this.number = number;
        this.symbol = symbol;
    }

    @Override
    public String toString() {
        String s = "<html>Name: " + name + " <br>Symbol: " + symbol + "<br>Atomic number:  " + number + "</html>";
        return s;
    }

    public String getName() {
        return name;
    }

    public int getNumber() {
        return number;
    }

    public String getSymbol() {
        return symbol;
    }

    public static Symbol findBySymbol(String abbr) {
        for (Symbol v : values()) {
            if (v.getSymbol().equals(abbr)) {
                return v;
            }
        }
        return null;
    }

}
