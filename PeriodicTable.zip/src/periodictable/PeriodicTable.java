/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package periodictable;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author F4829689
 */
public class PeriodicTable {

    private JFrame mainFrame;
    private JLabel resultLabel;
    private JLabel statusLabel;
    private JPanel controlPanel;
    private JLabel msglabel;

    public PeriodicTable() {
        prepareGUI();
    }

    public static void main(String[] args) {
        PeriodicTable swingLayoutDemo = new PeriodicTable();
        swingLayoutDemo.showFlowLayoutDemo();
    }

    private void prepareGUI() {
        mainFrame = new JFrame("Ddmurthare Periodic Table...");
        mainFrame.setSize(400, 400);
        mainFrame.setLayout(new GridLayout(3, 1));

        resultLabel = new JLabel("", JLabel.CENTER);
        statusLabel = new JLabel("asdasd", JLabel.CENTER);
        statusLabel.setSize(350, 100);

        mainFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent) {
                System.exit(0);
            }
        });

        controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());

        mainFrame.add(controlPanel);
        mainFrame.add(resultLabel);
        mainFrame.setVisible(true);
    }

    private void showFlowLayoutDemo() {

        JPanel panel = new JPanel();
        //panel.setBackground(Color.darkGray);
        panel.setSize(200, 200);
        FlowLayout layout = new FlowLayout();
        layout.setHgap(10);
        layout.setVgap(10);
        JTextField symbolField = new JTextField("", 15);

        panel.setLayout(layout);
        panel.add(new JLabel("Enter symbol"));
        panel.add(symbolField);
        controlPanel.add(panel);

        JButton button = new JButton("Get Symbol");
        button.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Symbol v = Symbol.findBySymbol(symbolField.getText());
                    resultLabel.setText(v.toString());
                } catch (Exception ex) {
                    resultLabel.setText("Not a valid Symbol!");
                }
            }
        });

        panel = new JPanel();
        // panel.setBackground(Color.darkGray);
        panel.setSize(200, 200);
        layout = new FlowLayout();
        layout.setHgap(10);
        layout.setVgap(10);

        panel.setLayout(layout);
        panel.add(button);
        controlPanel.add(panel);

        mainFrame.setVisible(true);
    }
}
